<?php
	$mycon=mysqli_connect("localhost","root","");
	mysqli_select_db($mycon,"members");
?>
